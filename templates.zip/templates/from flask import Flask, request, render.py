from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/preview', methods=['POST'])
def preview():
    if 'datasetfile' not in request.files:
        return 'No file part'
    file = request.files['datasetfile']
    if file.filename == '':
        return 'No selected file'
    # Process the file here, for demonstration let's just display the filename
    return f'Previewing file: {file.filename}'

if __name__ == '__main__':
    app.run(debug=True)
